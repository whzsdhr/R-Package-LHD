library(testthat)
library(LHD)

test_check("LHD")
